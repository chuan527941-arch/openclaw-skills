---
name: arm-notebook
description: 将 ARM-Markdown 复现指导手册转换为可直接在 Jupyter 中运行的 .ipynb Notebook。当用户提到 ARM-notebook、将 markdown 转为 notebook、生成 ipynb、创建 Jupyter 复现笔记本时使用。需要先有 ARM-Markdown 生成的 Markdown 文件。
---

# ARM-Notebook 生成器

读取 ARM-Markdown 生成的复现指导手册（Markdown），将其转换为结构化的 Jupyter Notebook（.ipynb），可直接在 Jupyter Lab/Notebook 中打开并逐步执行，完成论文复现。

## 目标

将 `ARM_Reproduction_Guide.md` 转换为 `ARM_Reproduction_Guide.ipynb`，保留完整的复现流程结构，使 Markdown 文本成为说明单元格（Markdown Cell），代码块成为可执行的代码单元格（Code Cell）。

## 第一步：定位 ARM-Markdown 文件

在 ARM 文件夹的 `report/` 目录下查找 `ARM_Reproduction_Guide.md`：

- `{ARM文件夹}/report/ARM_Reproduction_Guide.md`

**如果未找到该文件，提示用户先使用 ARM-markdown skill 生成 Markdown，或让用户提供 Markdown 文件的路径。**

## 第二步：读取并解析 Markdown

完整读取 Markdown 文件，按章节结构解析为以下两类内容：

| 内容类型 | 识别方式 | 转换目标 |
|----------|----------|----------|
| 说明文本 | 标题、段落、表格、列表、引用等 | Markdown Cell |
| 代码块 | ` ```python ... ``` ` 或 ` ```bash ... ``` ` 围栏代码块 | Code Cell |

解析规则：
- 每个一级/二级标题（`#` / `##`）开始一个新的 Markdown Cell
- 连续的非代码文本合并为同一个 Markdown Cell，直到遇到代码块或新标题
- 每个 ` ```python ``` ` 代码块独立转换为一个 Code Cell
- ` ```bash ``` ` 代码块转换为 Code Cell，每行命令前加 `!` 前缀使其可在 Notebook 中执行
- `<details>` 折叠块中的代码同样提取为 Code Cell
- 纯展示性的文本代码块（如目录结构示例、数据表格示例）保留在 Markdown Cell 中，不转为 Code Cell

## 第三步：生成 Notebook

使用 Python 脚本生成 `.ipynb` 文件。Notebook 的标准 JSON 结构如下：

```python
import json

notebook = {
    "nbformat": 4,
    "nbformat_minor": 5,
    "metadata": {
        "kernelspec": {
            "display_name": "Python 3",
            "language": "python",
            "name": "python3"
        },
        "language_info": {
            "name": "python",
            "version": "3.10.0"
        }
    },
    "cells": []
}
```

### 单元格构造

Markdown Cell：

```python
{
    "cell_type": "markdown",
    "metadata": {},
    "source": ["# 标题\n", "\n", "说明文本..."]
}
```

Code Cell：

```python
{
    "cell_type": "code",
    "metadata": {},
    "source": ["import pandas as pd\n", "df = pd.read_csv('data.csv')"],
    "execution_count": None,
    "outputs": []
}
```

### 转换脚本

在 ARM 文件夹的 `report/` 目录下执行以下 Python 脚本完成转换：

```python
import json
import re

def md_to_notebook(md_path, ipynb_path):
    with open(md_path, 'r', encoding='utf-8') as f:
        content = f.read()

    cells = []
    parts = re.split(r'(```(?:python|bash)\n.*?```)', content, flags=re.DOTALL)

    for part in parts:
        part = part.strip()
        if not part:
            continue

        bash_match = re.match(r'^```bash\n(.*?)```$', part, re.DOTALL)
        python_match = re.match(r'^```python\n(.*?)```$', part, re.DOTALL)

        if python_match:
            code = python_match.group(1).rstrip('\n')
            cells.append({
                "cell_type": "code",
                "metadata": {},
                "source": code.splitlines(True),
                "execution_count": None,
                "outputs": []
            })
        elif bash_match:
            code = bash_match.group(1).rstrip('\n')
            lines = ['!' + line if not line.startswith('#') else line
                     for line in code.splitlines()]
            cells.append({
                "cell_type": "code",
                "metadata": {},
                "source": [l + '\n' for l in lines],
                "execution_count": None,
                "outputs": []
            })
        else:
            cells.append({
                "cell_type": "markdown",
                "metadata": {},
                "source": part.splitlines(True)
            })

    notebook = {
        "nbformat": 4,
        "nbformat_minor": 5,
        "metadata": {
            "kernelspec": {
                "display_name": "Python 3",
                "language": "python",
                "name": "python3"
            },
            "language_info": {
                "name": "python",
                "version": "3.10.0"
            }
        },
        "cells": cells
    }

    with open(ipynb_path, 'w', encoding='utf-8') as f:
        json.dump(notebook, f, ensure_ascii=False, indent=1)

md_to_notebook('ARM_Reproduction_Guide.md', 'ARM_Reproduction_Guide.ipynb')
```

**也可以直接用 Write 工具按照上述 JSON 结构手动构建 .ipynb 文件，无需运行 Python 脚本。** 选择哪种方式取决于环境是否支持执行 Python。

## 第四步：质量检查

生成后验证：

- [ ] `.ipynb` 文件可被 Jupyter 正常打开（JSON 格式合法）
- [ ] 所有 Markdown 章节与原 Markdown 文件一一对应
- [ ] 所有 Python 代码块已转为可执行的 Code Cell
- [ ] Bash 命令已添加 `!` 前缀
- [ ] 单元格顺序与原文档逻辑流程一致
- [ ] 没有空单元格或格式残缺的单元格

## 第五步：保存并通知用户

将生成的 Notebook 保存至：`{ARM文件夹}/report/ARM_Reproduction_Guide.ipynb`

告知用户以下信息：

1. **文件路径**：Notebook 已存放在 `{ARM文件夹}/report/ARM_Reproduction_Guide.ipynb`，给出完整路径
2. **使用方式**：可通过 `jupyter lab` 或 `jupyter notebook` 直接打开该文件，逐单元格执行完成复现
3. **审查提醒**：请用户检查以下内容：
   - 代码单元格是否完整可运行
   - 数据文件路径是否需要根据实际环境调整
   - 环境依赖是否已安装

## 注意事项

- **文件路径适配**：Notebook 中的代码可能引用相对路径（如 `../../dataset/data.csv`），需根据 Notebook 实际存放位置调整路径，或在 Notebook 开头添加 `os.chdir()` 切换工作目录
- **大代码块拆分**：如果原 Markdown 中某个代码块过长（超过 50 行），可考虑按逻辑拆分为多个 Code Cell，每个 Cell 之间插入简短的 Markdown 说明
- **保留完整性**：不要省略原 Markdown 中的任何内容，包括表格、分析解读、结论等文本部分
- **编码格式**：`.ipynb` 文件使用 UTF-8 编码，`ensure_ascii=False` 以正确保存中文内容
