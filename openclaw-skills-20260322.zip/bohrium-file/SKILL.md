---
name: bohrium-file
description: "Manage Bohrium project files via openapi.dp.tech. Use when: user asks about browsing/uploading/downloading/moving/copying/deleting files on Bohrium, or creating directories. NOT for: dataset management, job submission, or node management."
---

# SKILL: Bohrium 文件管理 (File) API

## 概述

通过 `openapi.dp.tech` 管理 Bohrium 平台的项目文件，支持文件浏览、上传、下载、移动、复制、删除、创建目录等操作。文件以项目为单位组织，分为 `personal`（个人）和 `share`（共享）两个根目录。

## API 信息

| 项目 | 值 |
|------|-----|
| Base URL (v1) | `https://openapi.dp.tech/openapi/v1/file` |
| Base URL (v2) | `https://openapi.dp.tech/openapi/v2/file` |
| 认证方式 | Header `accessKey: <your-key>` |
| v1 转发目标 | bohrium-api `/bohrapi/v1/file/*` |
| v2 转发目标 | bohrium-api `/bohrapi/v2/file/*` |
| get_oss_url | bohrium-core `/api/v1/file/*` |

## 重要说明

- **v1 的 `iterate` 接口**需要传 `userId` 字段，否则会校验失败
- **v2 的 `iterate` 接口**使用 `pathKey`（int 类型，项目 ID）和 `pathType` 代替 `userId`/`projectId`
- **`download` 接口**返回 307 重定向到实际存储地址
- **v2 `upload/binary`** 是 GET 方法（返回上传凭证），不是 POST
- 文件路径不包含项目前缀，从 `personal/` 或 `share/` 开始

## 认证配置

ACCESS_KEY 从 OpenClaw 配置文件 `~/.openclaw/openclaw.json` 中读取：

```json
"bohrium-file": {
  "enabled": true,
  "apiKey": "YOUR_ACCESS_KEY",
  "env": {
    "ACCESS_KEY": "YOUR_ACCESS_KEY"
  }
}
```

在 Python 代码中，通过环境变量 `ACCESS_KEY` 获取：

```python
import os
access_key = os.environ.get("ACCESS_KEY", "")
```

OpenClaw 会自动将配置中的 `env.ACCESS_KEY` 注入到运行环境。

## 端点

### 1. 浏览文件列表（v1）

```
POST /openapi/v1/file/iterate
Content-Type: application/json
accessKey: <your-key>
```

**请求体：**

```json
{
    "path": "/personal/",
    "projectId": 154,
    "userId": 157
}
```

**参数说明：**

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `path` | string | 是 | 文件路径，如 `/`、`/personal/`、`/share/subdir/` |
| `projectId` | int | 是 | 项目 ID |
| `userId` | int | 是 | 用户 ID |

**响应示例：**

```json
{
    "code": 0,
    "data": {
        "hasNext": false,
        "nextToken": "",
        "objects": [
            {
                "isDir": true,
                "isSymLink": false,
                "lastModified": 0,
                "path": "share/",
                "title": "/share/",
                "size": 0,
                "permission": "rw",
                "fileVest": "project"
            },
            {
                "isDir": true,
                "isSymLink": false,
                "lastModified": 0,
                "path": "personal/",
                "title": "/personal/",
                "size": 0,
                "permission": "rw",
                "fileVest": "user"
            }
        ],
        "prefix": ""
    }
}
```

### 2. 浏览文件列表（v2）

```
POST /openapi/v2/file/iterate
Content-Type: application/json
accessKey: <your-key>
```

**请求体：**

```json
{
    "pathKey": 154,
    "pathType": "personal",
    "path": "/"
}
```

**参数说明：**

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `pathKey` | int | 是 | 项目 ID |
| `pathType` | string | 是 | 路径类型：`personal` 或 `share` |
| `path` | string | 是 | 子路径 |

### 3. 获取文件/目录状态

```
GET /openapi/v1/file/stat/{path}
accessKey: <your-key>
```

> `{path}` 为文件路径，如 `personal/mydir`。

**响应示例：**

```json
{
    "code": 0,
    "data": {
        "cacheControl": "",
        "contentDisposition": "",
        "contentEncoding": "",
        "contentLanguage": "",
        "contentLength": 0,
        "contentType": "",
        "entityTag": "",
        "exist": true,
        "expires": "",
        "fileType": "dir",
        "lastModified": "Mon, 01 Jan 0001 00:00:00 GMT",
        "nextAppendPosition": 0,
        "path": "157/NezWT0Zwsn/personal/mydir"
    }
}
```

### 4. 获取文件元数据

```
GET /openapi/v1/file/meta/{path}
accessKey: <your-key>
```

**响应示例：**

```json
{
    "code": 0,
    "data": {
        "contentLength": 0,
        "contentType": "",
        "exist": true,
        "path": "157/NezWT0Zwsn/personal",
        "bohrDownUrl": "https://tiefblue-nas.dp.tech/api/v2/result/.../157/NezWT0Zwsn/personal/"
    }
}
```

### 5. 下载文件

```
GET /openapi/v1/file/download/{path}
accessKey: <your-key>
```

> 返回 **307 重定向**到实际下载地址。

### 6. 下载文件（v2）

```
GET /openapi/v2/file/download/{path}
accessKey: <your-key>
```

### 7. 获取上传凭证（v2）

```
GET /openapi/v2/file/upload/binary?projectId={projectId}&path={path}
accessKey: <your-key>
```

**查询参数：**

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `projectId` | int | 是 | 项目 ID |
| `path` | string | 是 | 目标路径，如 `/personal/test.txt` |

**响应示例：**

```json
{
    "code": 0,
    "data": {
        "host": "https://tiefblue-nas.dp.tech",
        "Authorization": "Bearer eyJhbGciOi...",
        "X-Storage-Param": "eyJwYXRoIjoi..."
    }
}
```

> 使用返回的 `host`、`Authorization` 和 `X-Storage-Param` 向存储服务上传文件。

### 8. 创建目录

```
POST /openapi/v1/file/mkdir
Content-Type: application/json
accessKey: <your-key>
```

**请求体：**

```json
{
    "path": "/personal/new-folder",
    "projectId": 154,
    "userId": 157
}
```

**响应示例：**

```json
{
    "code": 0,
    "data": {
        "path": "personal/new-folder/"
    }
}
```

### 9. 删除文件/目录

```
DELETE /openapi/v1/file/delete/{path}
accessKey: <your-key>
```

**请求体（可选）：**

```json
{"projectId": 154, "userId": 157}
```

**响应示例：**

```json
{"code": 0}
```

### 10. 递归删除

```
DELETE /openapi/v1/file/deleter/{path}
accessKey: <your-key>
```

### 11. 移动文件

```
POST /openapi/v1/file/move
Content-Type: application/json
accessKey: <your-key>
```

**请求体：**

```json
{
    "src": "personal/old-name.txt",
    "dst": "personal/new-name.txt",
    "projectId": 154,
    "userId": 157
}
```

### 12. 递归移动

```
POST /openapi/v1/file/mover
Content-Type: application/json
accessKey: <your-key>
```

### 13. 复制文件

```
POST /openapi/v1/file/copy
Content-Type: application/json
accessKey: <your-key>
```

**请求体：**

```json
{
    "src": "personal/source.txt",
    "dst": "personal/copy.txt",
    "projectId": 154,
    "userId": 157
}
```

### 14. 递归复制

```
POST /openapi/v1/file/copyr
Content-Type: application/json
accessKey: <your-key>
```

### 15. 获取最近访问文件

```
GET /openapi/v1/file/recent
accessKey: <your-key>
```

**响应示例：**

```json
{
    "code": 0,
    "data": [
        {
            "fileName": "test.py",
            "path": "157/NezWT0Zwsn/personal/DeepSeek/test.py",
            "projectId": 12560,
            "projectName": "unconditional_i_865c",
            "mountPath": "/personal/DeepSeek/test.py"
        }
    ]
}
```

### 16. 解压文件

```
POST /openapi/v1/file/decompress
Content-Type: application/json
accessKey: <your-key>
```

**请求体：**

```json
{
    "path": "personal/archive.zip",
    "projectId": 154,
    "userId": 157
}
```

### 17. 获取传输任务列表

```
GET /openapi/v1/file/transfer/list?page=1&pageSize=10
accessKey: <your-key>
```

**响应示例：**

```json
{
    "code": 0,
    "data": {
        "items": []
    }
}
```

### 18. 创建传输任务

```
POST /openapi/v1/file/transfer/add
Content-Type: application/json
accessKey: <your-key>
```

### 19. 搜索配置

```
POST /openapi/v1/file/search/config
Content-Type: application/json
accessKey: <your-key>
```

### 20. 文件修改（v2）

```
POST /openapi/v2/file/modify
Content-Type: application/json
accessKey: <your-key>
```

## Python 代码示例

```python
import requests
from typing import Optional, Dict, Any, List


class FileClient:
    def __init__(
        self,
        host: str = "https://openapi.dp.tech/openapi",
        access_key: str = "",
    ):
        self.host = host
        self.access_key = access_key

    def _headers(self) -> Dict[str, str]:
        return {"accessKey": self.access_key}

    def _headers_json(self) -> Dict[str, str]:
        return {"accessKey": self.access_key, "Content-Type": "application/json"}

    def _get(self, path: str, params: Optional[Dict] = None) -> Dict[str, Any]:
        resp = requests.get(f"{self.host}{path}", headers=self._headers(), params=params)
        resp.raise_for_status()
        return resp.json()

    def _post(self, path: str, json_data: Optional[Dict] = None) -> Dict[str, Any]:
        resp = requests.post(f"{self.host}{path}", headers=self._headers_json(), json=json_data or {})
        resp.raise_for_status()
        return resp.json()

    def _delete(self, path: str, json_data: Optional[Dict] = None) -> Dict[str, Any]:
        resp = requests.delete(f"{self.host}{path}", headers=self._headers_json(), json=json_data)
        resp.raise_for_status()
        return resp.json()

    # ---------- 浏览类 ----------

    def iterate(self, path: str, project_id: int, user_id: int) -> List[Dict]:
        """浏览文件列表（v1）"""
        data = self._post("/v1/file/iterate", {
            "path": path,
            "projectId": project_id,
            "userId": user_id,
        })
        return data.get("data", {}).get("objects", [])

    def iterate_v2(self, path_key: int, path_type: str, path: str = "/") -> List[Dict]:
        """浏览文件列表（v2）"""
        data = self._post("/v2/file/iterate", {
            "pathKey": path_key,
            "pathType": path_type,
            "path": path,
        })
        return data.get("data", {}).get("objects", [])

    def stat(self, file_path: str) -> Dict:
        """获取文件/目录状态"""
        data = self._get(f"/v1/file/stat/{file_path}")
        return data.get("data", {})

    def meta(self, file_path: str) -> Dict:
        """获取文件元数据"""
        data = self._get(f"/v1/file/meta/{file_path}")
        return data.get("data", {})

    def recent(self) -> List[Dict]:
        """获取最近访问文件"""
        data = self._get("/v1/file/recent")
        return data.get("data", [])

    def transfer_list(self, page: int = 1, page_size: int = 10) -> List[Dict]:
        """获取传输任务列表"""
        data = self._get("/v1/file/transfer/list", {"page": page, "pageSize": page_size})
        return data.get("data", {}).get("items", [])

    # ---------- 操作类 ----------

    def mkdir(self, path: str, project_id: int, user_id: int) -> Dict:
        """创建目录"""
        return self._post("/v1/file/mkdir", {
            "path": path,
            "projectId": project_id,
            "userId": user_id,
        })

    def delete(self, file_path: str, project_id: int = 0, user_id: int = 0) -> Dict:
        """删除文件/目录"""
        return self._delete(f"/v1/file/delete/{file_path}", {
            "projectId": project_id,
            "userId": user_id,
        })

    def delete_recursive(self, file_path: str, project_id: int = 0, user_id: int = 0) -> Dict:
        """递归删除目录"""
        return self._delete(f"/v1/file/deleter/{file_path}", {
            "projectId": project_id,
            "userId": user_id,
        })

    def move(self, src: str, dst: str, project_id: int, user_id: int) -> Dict:
        """移动/重命名文件"""
        return self._post("/v1/file/move", {
            "src": src,
            "dst": dst,
            "projectId": project_id,
            "userId": user_id,
        })

    def copy(self, src: str, dst: str, project_id: int, user_id: int) -> Dict:
        """复制文件"""
        return self._post("/v1/file/copy", {
            "src": src,
            "dst": dst,
            "projectId": project_id,
            "userId": user_id,
        })

    def decompress(self, path: str, project_id: int, user_id: int) -> Dict:
        """解压文件"""
        return self._post("/v1/file/decompress", {
            "path": path,
            "projectId": project_id,
            "userId": user_id,
        })

    def get_upload_token_v2(self, project_id: int, path: str) -> Dict:
        """获取上传凭证（v2），返回 host/Authorization/X-Storage-Param"""
        data = self._get("/v2/file/upload/binary", {
            "projectId": project_id,
            "path": path,
        })
        return data.get("data", {})

    def download_url(self, file_path: str) -> str:
        """获取文件下载地址（v1，返回 307 重定向目标）"""
        resp = requests.get(
            f"{self.host}/v1/file/download/{file_path}",
            headers=self._headers(),
            allow_redirects=False,
        )
        return resp.headers.get("Location", "")

    # ---------- 上传文件 ----------

    def upload_file(self, project_id: int, remote_path: str, local_file_path: str) -> bool:
        """
        上传本地文件到 Bohrium 存储
        1. 获取上传凭证
        2. 使用凭证上传到存储服务
        """
        # Step 1: 获取上传凭证
        token_data = self.get_upload_token_v2(project_id, remote_path)
        host = token_data.get("host", "")
        auth = token_data.get("Authorization", "")
        storage_param = token_data.get("X-Storage-Param", "")

        if not host or not auth:
            raise ValueError("获取上传凭证失败")

        # Step 2: 上传文件
        with open(local_file_path, "rb") as f:
            resp = requests.put(
                f"{host}/api/v2/upload",
                headers={
                    "Authorization": auth,
                    "X-Storage-Param": storage_param,
                },
                data=f,
            )
        return resp.status_code == 200


# ---------- 使用示例 ----------
if __name__ == "__main__":
    client = FileClient(access_key="YOUR_ACCESS_KEY")
    PROJECT_ID = 154
    USER_ID = 157

    # 1. 浏览根目录
    root = client.iterate("/", PROJECT_ID, USER_ID)
    for obj in root:
        print(f"  {'[DIR]' if obj['isDir'] else '[FILE]'} {obj['path']} ({obj['size']} bytes)")

    # 2. 浏览个人目录
    personal = client.iterate("/personal/", PROJECT_ID, USER_ID)
    for obj in personal:
        print(f"  {obj['path']} (size={obj['size']})")

    # 3. 检查文件状态
    info = client.stat("personal/DeepSeek")
    print(f"类型: {info.get('fileType')}, 存在: {info.get('exist')}")

    # 4. 获取最近文件
    recent = client.recent()
    for f in recent[:3]:
        print(f"  {f['fileName']} ({f['projectName']})")

    # 5. 创建目录
    client.mkdir("/personal/my-workspace", PROJECT_ID, USER_ID)
    print("目录已创建")

    # 6. 获取上传凭证
    token = client.get_upload_token_v2(PROJECT_ID, "/personal/test.txt")
    print(f"上传到: {token.get('host')}")

    # 7. 上传文件
    # client.upload_file(PROJECT_ID, "/personal/test.txt", "/local/path/test.txt")

    # 8. 下载文件（获取重定向URL）
    url = client.download_url("personal/test.txt")
    print(f"下载地址: {url}")

    # 9. 清理
    client.delete("personal/my-workspace", PROJECT_ID, USER_ID)
    print("目录已删除")
```

## curl 示例

```bash
AK="YOUR_ACCESS_KEY"

# === v1 文件操作 ===

# 浏览根目录
curl -s -X POST "https://openapi.dp.tech/openapi/v1/file/iterate" \
  -H "accessKey: $AK" \
  -H "Content-Type: application/json" \
  -d '{"path":"/","projectId":154,"userId":157}'

# 浏览个人目录
curl -s -X POST "https://openapi.dp.tech/openapi/v1/file/iterate" \
  -H "accessKey: $AK" \
  -H "Content-Type: application/json" \
  -d '{"path":"/personal/","projectId":154,"userId":157}'

# 文件状态
curl -s "https://openapi.dp.tech/openapi/v1/file/stat/personal/DeepSeek" -H "accessKey: $AK"

# 文件元数据
curl -s "https://openapi.dp.tech/openapi/v1/file/meta/personal" -H "accessKey: $AK"

# 最近文件
curl -s "https://openapi.dp.tech/openapi/v1/file/recent" -H "accessKey: $AK"

# 创建目录
curl -s -X POST "https://openapi.dp.tech/openapi/v1/file/mkdir" \
  -H "accessKey: $AK" \
  -H "Content-Type: application/json" \
  -d '{"path":"/personal/new-folder","projectId":154,"userId":157}'

# 删除文件/目录
curl -s -X DELETE "https://openapi.dp.tech/openapi/v1/file/delete/personal/new-folder" \
  -H "accessKey: $AK" \
  -H "Content-Type: application/json" \
  -d '{"projectId":154,"userId":157}'

# 移动文件
curl -s -X POST "https://openapi.dp.tech/openapi/v1/file/move" \
  -H "accessKey: $AK" \
  -H "Content-Type: application/json" \
  -d '{"src":"personal/old.txt","dst":"personal/new.txt","projectId":154,"userId":157}'

# 复制文件
curl -s -X POST "https://openapi.dp.tech/openapi/v1/file/copy" \
  -H "accessKey: $AK" \
  -H "Content-Type: application/json" \
  -d '{"src":"personal/source.txt","dst":"personal/copy.txt","projectId":154,"userId":157}'

# 下载文件（返回 307 重定向）
curl -s -L "https://openapi.dp.tech/openapi/v1/file/download/personal/test.txt" \
  -H "accessKey: $AK" -o test.txt

# 传输任务列表
curl -s "https://openapi.dp.tech/openapi/v1/file/transfer/list?page=1&pageSize=10" \
  -H "accessKey: $AK"

# === v2 文件操作 ===

# 获取上传凭证
curl -s "https://openapi.dp.tech/openapi/v2/file/upload/binary?projectId=154&path=/personal/test.txt" \
  -H "accessKey: $AK"

# 使用上传凭证上传文件
# 先从上面获取 Authorization 和 X-Storage-Param，然后：
# curl -X PUT "https://tiefblue-nas.dp.tech/api/v2/upload" \
#   -H "Authorization: Bearer eyJ..." \
#   -H "X-Storage-Param: eyJ..." \
#   --data-binary @local-file.txt
```

## 常见问题

| 问题 | 原因 | 解决 |
|------|------|------|
| v1 iterate 报 UserId validation failed | 缺少 `userId` 字段 | 请求体中必须包含 `userId` |
| v2 iterate 报 pathKey 类型错误 | `pathKey` 应为 int 而非 string | 确保 JSON 中 `pathKey` 是数字类型 |
| download 无法获取文件内容 | 返回 307 重定向 | 使用 `-L` 参数跟随重定向，或读取 `Location` 头 |
| move/copy 报 "prefix is nil" | 路径格式不正确 | 确保路径以 `personal/` 或 `share/` 开头，不带前导 `/` |
| upload 报 "path invalid" | 上传路径格式错误 | v2 上传使用 GET 获取凭证，路径以 `/personal/` 开头 |
| accounting 报 "userId is required" | 此接口需要额外的 userId 参数 | 通过 bohrium-core 转发时自动注入，openapi 可能不支持 |
