---
name: file2arm-organization
description: Organize workspace files into ARM (Agent Ready Manuscript) directory structure. Use when the user asks to organize files into ARM format, create ARM structure, arrange reproduction files, or mentions ARM/manuscript organization.
---

# File2ARM Organization

将工作空间中的各类文件整理为标准 ARM（Agent Ready Manuscript）目录结构。

## ARM 固定目录结构

ARM 目录**直接创建在工作空间根目录下**，文件夹名称固定为 `ARM`。即：`<workspace>/ARM/`。

**以下 9 个一级子目录是固定不变的，不可增删、不可重命名、不可调整层级。** 每次整理必须严格创建且仅创建这 9 个目录：

```
<workspace>/ARM/
├── paper/         # 论文相关
├── plan/          # 复现计划
├── code/          # 代码文件
├── trace/         # Agent 执行日志
├── dataset/       # 数据集
├── result/        # 结果与图表
├── report/        # Notebook + Dockerfile
├── information/   # 模型信息与经验总结
└── others/        # 无法明确归类的文件
```

**强制约束**：
- 父目录名固定为 `ARM`，不可改名
- ARM 目录位于工作空间根目录下，路径为 `<workspace>/ARM/`
- 禁止在 `ARM/` 下创建上述 9 个目录以外的任何一级目录
- 禁止省略任何一个目录，即使该目录下没有文件也必须创建空目录
- 目录名称必须全小写，与上方完全一致
- 所有文件必须归入这 9 个目录之一，不允许散落在 `ARM/` 根下

**二级子目录规则**：
- 每个一级目录下可以根据实际内容**灵活创建二级子目录**来分组管理
- 子目录命名应语义清晰，反映其包含内容的类别
- 示例：
  - `code/data_preprocessing/`、`code/model_training/`、`code/visualization/` — 按任务阶段分组代码
  - `result/ML_Analysis/figures/`、`result/ML_Analysis/intermediate_results/` — 按分析任务和产出类型分层
  - `dataset/raw/`、`dataset/processed/` — 区分原始与处理后的数据
  - `paper/figures/`、`paper/parsed_text/` — 区分论文原始 PDF 和提取物
- 如果某个一级目录下文件数量少且类别单一，可以不建子目录，直接平铺放置

## 整理流程

### Step 1: 确认工作空间

确认当前工作空间路径（即 `<workspace>`）。ARM 目录固定为 `<workspace>/ARM/`，无需向用户额外确认目标路径。

整理操作会扫描工作空间中 `ARM/` 目录之外的文件，将它们归类到 `<workspace>/ARM/` 下对应的子目录中。

### Step 2: 创建目录结构

在工作空间下创建 `ARM/` 及全部 9 个子目录：

```bash
mkdir -p <workspace>/ARM/{paper,plan,code,trace,dataset,result,report,information,others}
```

### Step 3: 按规则分类并放置文件

扫描源工作空间，根据以下规则将文件归入对应目录：

#### paper/ — 论文相关文件

| 文件类型 | 说明 |
|---------|------|
| 论文原始 PDF | 通常命名含 paper/article/manuscript |
| paper_id 或元信息文件 | 如 paper_id.txt、metadata.json |
| 解析后的纯文本 | 从 PDF 提取的 .txt/.md |
| 论文中的图表数据 | 从论文提取的 figure/table 数据 |

#### plan/ — 复现计划

| 文件类型 | 说明 |
|---------|------|
| 复现计划文档 | 通常为 markdown 格式（plan.md 等） |
| 步骤说明 | 实验步骤、工作流程描述 |

#### code/ — 代码

| 文件类型 | 说明 |
|---------|------|
| 脚本文件 | .py, .r, .sh, .jl 等 |
| 代码目录 | 含源码的文件夹整体放入 |

**注意**：不包含 ARM_Notebook（ARM_Notebook.ipynb 归入 report/）和 Dockerfile（归入 report/）。

#### trace/ — Agent 执行日志

存放 Agent 执行过程中的 session 记录。

**固定来源路径**：`/root/.openclaw/agents/main/sessions/*.jsonl`

操作方式：将该目录下的 `.jsonl` 文件**复制**到 `<workspace>/ARM/trace/` 下（始终使用 move）。

```bash
cp /root/.openclaw/agents/main/sessions/*.jsonl <workspace>/ARM/trace/
```

如果 `/root/.openclaw/agents/main/sessions/` 不存在或为空，仅创建空的 trace/ 目录即可。

#### dataset/ — 数据集

| 文件类型 | 说明 |
|---------|------|
| 数据文件 | .csv, .xlsx, .json, .parquet 等 |
| 数据集下载链接 | 含下载 URL 的说明文件 |
| 数据集描述 | 字段介绍、数据说明文档 |

#### result/ — 结果文件

| 文件类型 | 说明 |
|---------|------|
| 运行结果 | 模型输出、分析摘要等 |
| 图表 | 生成的 .png, .jpg, .svg 等 |
| 中间结果 | 中间步骤产出的数据文件 |

**提示**：result/ 下可按分析任务创建子目录（如 `result/ML_Analysis/`），子目录内可进一步分为 `figures/`、`intermediate_results/`、`final_results/`。

#### report/ — ARM_Notebook 与 Dockerfile

| 文件类型 | 说明 |
|---------|------|
| Notebook | .md 文件，命名为ARM_Notebook.md |
| Jupyter Notebook | .ipynb 文件，命名为ARM_Notebook.ipynb |
| Dockerfile | 用于构建复现环境的镜像定义 |

**特殊规则**：
- ARM_Notebook.md 和 ARM_Notebook.ipynb的关系为：ARM_Notebook.ipynb通过ARM_Notebook.md改写得到，两者同属于ARM（Agent Ready Manuscript）
- 如果工作空间中存在ARM内容的`.md`文件、 `.ipynb` 文件和 `Dockerfile`，将它们放入 report/
- 如果工作空间中不存在这两个文件，仅创建空的 report/ 目录即可
- Dockerfile 用于在平台上构建自定义镜像，并用该镜像运行 Notebook

#### information/ — 模型信息与经验

| 文件类型 | 说明 |
|---------|------|
| 人类经验总结 | 复现过程中的经验、注意事项 |

### Step 4: 处理歧义文件

如果某个文件的归属不明确：

1. 优先根据文件内容（而非仅文件名）判断
2. 数据类文件（.csv 等）若明确是实验原始数据则放 dataset/，若是运行产生的结果则放 result/
3. 如果能大致判断归属，直接放入对应目录，不必事事询问用户
4. 无法归入前 8 个目录的文件，放入 `others/`
5. 仅在**非常不确定**且文件看起来很重要时，才向用户确认归属

### Step 5: 生成整理报告

完成整理后，在工作空间根目录下生成 `ARM_Organization_Report.md` 文件，并提醒用户检查。

报告文件路径：`<workspace>/ARM_Organization_Report.md`

报告模板：

```markdown
# ARM 整理报告

> 生成时间：YYYY-MM-DD HH:MM:SS
>
> **请检查以下整理结果，确认文件归类是否正确。如有误分类，请手动调整。**

## 整理概览

| 目录 | 文件数 |
|------|--------|
| paper/ | N |
| plan/ | N |
| code/ | N |
| trace/ | N |
| dataset/ | N |
| result/ | N |
| report/ | N |
| information/ | N |
| others/ | N |
| **合计** | **N** |

## 各目录详情

### paper/
- `paper/file1.pdf`
- `paper/subfolder/file2.txt`
- ...

### plan/
- ...

（逐个目录列出所有文件的相对路径）

### others/
- `others/unknown_file.xyz` — 无法明确归类，请确认
- ...

## 需要关注

- [ ] 请检查 others/ 中的文件，确认是否需要移至其他目录
- [ ] 请检查各目录的文件归类是否符合预期
- [ ] 如有子目录分组不合理，可手动调整
```

同时在对话中提醒用户：**整理报告已生成在 `<workspace>/ARM_Organization_Report.md`，请查看并确认文件归类是否正确。**

## 注意事项

- 对于 result/ 目录，如果有多类分析任务，应按任务建子目录组织
- code/ 中不放 Notebook 和 Dockerfile，这两者专属于 report/
- 不要移动或复制 `.git/`、`node_modules/`、`__pycache__/`、`.venv/` 等环境/版本控制目录
- 如果源文件和目标位置相同，跳过该文件

