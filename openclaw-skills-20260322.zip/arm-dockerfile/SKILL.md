---
name: arm-dockerfile
description: 综合分析复现任务的全部环境信息（ARM 文件夹、当前容器环境、复现过程文件等），生成 Dockerfile 用于在 Bohrium（玻尔）平台构建镜像。当用户提到 ARM-dockerfile、生成 Dockerfile、构建复现环境镜像、玻尔平台镜像时使用。
---

# ARM-Dockerfile 生成器

综合分析用户复现任务涉及的所有环境信息，生成一个正确、完整、可直接用于 Bohrium 平台打镜像的 Dockerfile，确保复现环境无遗漏。
你可以在https://docs.bohrium.com/docs/software/OtherSoftwares/中查看玻尔平台基于Dockerfile制作镜像的细节。

## 目标

从多个来源全面采集复现所需的环境依赖和配置，交叉验证后生成 Dockerfile。不仅限于 ARM 文件夹，还需参考当前运行容器的实际环境、复现过程中产生的所有文件。

## 第一步：多来源依赖采集

从以下 **所有可用来源** 综合提取依赖信息，确保无遗漏：

### 1.1 ARM 文件夹

| 来源 | 提取内容 |
|------|----------|
| `code/*.py` | 所有 `import` / `from ... import` 语句 |
| `result/` 下的脚本和代码 | 额外的依赖引用 |
| `report/ARM_Reproduction_Guide.md` | 环境配置章节中的依赖列表 |
| `report/Dockerfile`（如已有） | 参考现有 Dockerfile 的配置 |
| `report/*.ipynb` | Notebook 中的代码单元格引用的包 |

**如果 ARM 文件夹路径不确定，先向用户确认。**

### 1.2 当前容器/系统环境

在终端中执行以下命令，采集当前实际运行环境的信息：

```bash
# Python 包及版本
pip list --format=freeze

# Python 版本
python --version

# 系统已安装的 apt 包
dpkg --get-selections | grep -v deinstall

# 操作系统信息
cat /etc/os-release

# conda 环境（如有）
conda list 2>/dev/null || echo "no conda"
```

**重要**：不要把容器中所有已安装的包都写入 Dockerfile。只将复现任务实际需要的包纳入，用当前环境的信息来确认版本号和包名。

### 1.3 复现过程文件

扫描整个工作空间中与复现相关的文件：

| 文件类型 | 位置 | 提取内容 |
|----------|------|----------|
| `requirements.txt` | 工作空间任意位置 | 直接使用其中的包列表和版本 |
| `setup.py` / `pyproject.toml` | 工作空间任意位置 | 项目依赖声明 |
| `environment.yml` | 工作空间任意位置 | conda 环境依赖 |
| `*.py` / `*.sh` | 整个复现目录 | 脚本中的依赖引用和系统命令调用 |
| `Makefile` | 工作空间任意位置 | 编译依赖和工具链 |

### 1.4 依赖映射规则

Python 模块名与 pip 包名的常见差异映射：

| import 语句 | pip 包名 |
|------------|----------|
| `import cv2` | `opencv-python` |
| `import sklearn` | `scikit-learn` |
| `import PIL` | `Pillow` |
| `import yaml` | `PyYAML` |
| `import Bio` | `biopython` |
| `import wx` | `wxPython` |
| `import attr` | `attrs` |
| `import serial` | `pyserial` |

标准库模块（`os`、`sys`、`json`、`re`、`math`、`collections` 等）不需要安装，应排除在外。

## 第二步：依赖整合与去重

将所有来源的依赖汇总后：

1. **去重**：合并相同包的不同来源记录
2. **版本确定**：
   - 优先使用 `requirements.txt` 中的固定版本
   - 其次使用当前容器中 `pip list` 显示的实际版本
   - 如无明确版本，使用不带版本号的包名（安装最新版）
3. **分类**：区分系统依赖（apt）和 Python 依赖（pip）
4. **排除基础镜像自带内容**：`registry.dp.tech/dptech/ubuntu:20.04-py3.10` 已包含 Python 3.10 和基础系统工具，不需要重复安装
5. **识别隐式依赖**：某些 Python 包需要系统库支持，如：
   - `matplotlib` → 可能需要 `libfreetype6-dev`、`libpng-dev`
   - `opencv-python` → 需要 `libgl1-mesa-glx`、`libglib2.0-0`
   - `scipy` / `numpy` → 可能需要 `liblapack-dev`、`libblas-dev`
   - `h5py` → 需要 `libhdf5-dev`
   - `lxml` → 需要 `libxml2-dev`、`libxslt1-dev`

## 第三步：生成 Dockerfile

### 基础镜像

默认使用：

```dockerfile
FROM registry.dp.tech/dptech/ubuntu:20.04-py3.10
```

**仅当用户明确指定其他基础镜像时才更换。**

### Bohrium 平台要求

1. **必须安装 SSH 登录组件**：`openssh-server`、`supervisor`、`net-tools`
2. **pip 必须使用国内镜像源**（清华源），否则下载失败
3. **apt-get 必须使用国内镜像源**（阿里云源），否则下载失败
4. **不支持 COPY/ADD 本地文件**（Bohrium 平台限制）
5. 镜像大小不超过 40GB

### Dockerfile 模板

```dockerfile
FROM registry.dp.tech/dptech/ubuntu:20.04-py3.10

ENV DEBIAN_FRONTEND=noninteractive

# 使用国内镜像源（Bohrium 平台要求）
RUN sed -i 's/archive.ubuntu.com/mirrors.aliyun.com/g' /etc/apt/sources.list && \
    sed -i 's/security.ubuntu.com/mirrors.aliyun.com/g' /etc/apt/sources.list

# 安装系统依赖 + SSH 组件（Bohrium 平台要求）
RUN apt-get update && apt-get install -y --no-install-recommends \
    openssh-server \
    supervisor \
    net-tools \
    [其他系统依赖] \
    && rm -rf /var/lib/apt/lists/* \
    && mkdir -p /var/run/sshd \
    && echo 'root:root' | chpasswd \
    && sed -i 's/#PermitRootLogin prohibit-password/PermitRootLogin yes/' /etc/ssh/sshd_config

# 安装 Python 依赖（清华镜像源）
RUN pip install -i https://pypi.tuna.tsinghua.edu.cn/simple --no-cache-dir \
    [Python 包==版本号]

# 设置工作目录
WORKDIR /root/Paper_Reproduction

# 配置 Supervisor
RUN echo '[supervisord]\nnodaemon=true\n\n[program:sshd]\ncommand=/usr/sbin/sshd -D\nautostart=true\nautorestart=true' > /etc/supervisor/conf.d/supervisord.conf

EXPOSE 22
CMD ["/usr/bin/supervisord", "-c", "/etc/supervisor/conf.d/supervisord.conf"]
```

### 填充规则

1. **系统依赖**：SSH 三件套 + 复现所需的系统库，合并到同一个 `RUN apt-get install` 中
2. **Python 依赖**：按功能分组并附注释说明，尽量带版本号锁定
3. **合并 RUN 层**：减少镜像层数和体积
4. **清理缓存**：`apt-get` 后 `rm -rf /var/lib/apt/lists/*`；`pip` 使用 `--no-cache-dir`
5. **jupyterlab**：始终包含 `jupyterlab`，方便用户在 Bohrium 节点上使用 Notebook

## 第四步：正确性验证

生成后逐项检查：

- [ ] `FROM` 镜像地址正确（默认 `registry.dp.tech/dptech/ubuntu:20.04-py3.10`）
- [ ] SSH 三件套已安装：`openssh-server`、`supervisor`、`net-tools`
- [ ] apt-get 使用了阿里云源（`mirrors.aliyun.com`）
- [ ] pip 使用了清华源（`https://pypi.tuna.tsinghua.edu.cn/simple`）
- [ ] 无 `COPY` / `ADD` 指令（Bohrium 不支持）
- [ ] Python 包名正确（模块名→包名映射无误，排除了标准库）
- [ ] `DEBIAN_FRONTEND=noninteractive` 已设置
- [ ] 每个 `apt-get install` 前有 `apt-get update`
- [ ] SSH 配置完整（`PermitRootLogin yes`、`/var/run/sshd`）
- [ ] Supervisor 配置文件格式正确
- [ ] `EXPOSE 22` 和 `CMD` 存在
- [ ] 与当前容器中实际可运行的环境做交叉对比，确认无遗漏关键依赖

## 第五步：保存并通知用户

将 Dockerfile 保存至：`{ARM文件夹}/report/Dockerfile`

**如已有 Dockerfile，先备份为 `Dockerfile.bak`，再写入新文件。**

告知用户：

1. **文件路径**：Dockerfile 已存放在 `{ARM文件夹}/report/Dockerfile`，给出完整路径
2. **使用方式**：在 Bohrium 平台"镜像中心 → 自定义镜像 → 创建镜像"中，选择"基于 Dockerfile"构建，粘贴内容即可
3. **依赖来源说明**：简要列出依赖的采集来源（代码分析 / 当前环境 / requirements.txt 等），让用户了解每个包为何被纳入
4. **审查提醒**：请用户检查：
   - 包版本是否需要进一步锁定
   - 是否有遗漏的系统级依赖（尤其是编译型依赖）
   - 工作目录路径是否符合预期
   - 如有特殊软件（VASP 等商业软件），需自行处理授权和安装
   - 当前环境中手动配置的环境变量、别名等是否需要写入 Dockerfile

## 注意事项

- **不使用 COPY/ADD**：如需数据文件，应在容器启动后通过 Bohrium 数据管理挂载，或用 `wget`/`curl` 下载
- **镜像体积控制**：超过 40GB 会构建失败，不要安装不必要的包
- **国内镜像源**：pip 和 apt-get 都必须用国内源
- **基础镜像自带内容**：不要重复安装 Python 3.10 和基础系统工具
- **环境信息仅作参考**：当前容器的 `pip list` 结果用于确认版本号和识别遗漏，不要无脑全部写入
