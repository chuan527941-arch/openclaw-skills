#!/usr/bin/env python3
"""Upload ARM (Agent Ready Manuscript) to Paper2ARM Hub.

Full pipeline: find zip -> auth -> ensure paper -> create series -> create version
-> get STS credentials -> upload to OSS -> complete -> poll status.
"""

import argparse
import glob
import json
import os
import sys
import time

DEFAULT_HUB_URL = os.environ.get("ARM_HUB_URL", "https://arm.bohrium.com")
DEFAULT_TOKEN = os.environ.get("ARM_HUB_TOKEN", "")
DEFAULT_VERSION = "v1.0"
DEFAULT_MAX_RETRIES = 3
POLL_INTERVAL = 3
POLL_TIMEOUT = 120
MULTIPART_THRESHOLD = 5 * 1024 * 1024  # 5 MB


def _import_deps():
    """Import third-party deps at call time so --help works without them."""
    global requests, oss2
    try:
        import requests as _requests
        import oss2 as _oss2
    except ImportError as e:
        print(f"Missing dependency: {e.name}", file=sys.stderr)
        print("Run: pip install -r ~/.openclaw/skills/upload-arm/requirements.txt",
              file=sys.stderr)
        sys.exit(1)
    requests = _requests
    oss2 = _oss2


def _retry(fn, *, max_retries: int = DEFAULT_MAX_RETRIES,
           backoff_base: float = 1.0, context: str = ""):
    """Execute *fn* with exponential-backoff retry on transient failures."""
    last_exc = None
    for attempt in range(1, max_retries + 1):
        try:
            return fn()
        except Exception as exc:
            last_exc = exc
            retriable = _is_retriable(exc)
            if not retriable or attempt == max_retries:
                raise
            wait = backoff_base * (2 ** (attempt - 1))
            tag = f" [{context}]" if context else ""
            print(f"  Retry {attempt}/{max_retries}{tag}: {exc} "
                  f"(waiting {wait:.0f}s)")
            time.sleep(wait)
    raise last_exc  # unreachable, but keeps type-checkers happy


def _is_retriable(exc: Exception) -> bool:
    """Return True for transient / server-side errors worth retrying."""
    if isinstance(exc, (ConnectionError, TimeoutError, OSError)):
        return True
    if hasattr(exc, "response"):
        code = getattr(exc.response, "status_code", 0)
        return code >= 500 or code == 429
    msg = str(exc).lower()
    return any(kw in msg for kw in ("timeout", "connection", "http 5",
                                     "http 429", "temporarily"))


class ARMHubClient:
    """Thin wrapper around ARM Hub REST API with automatic retries."""

    def __init__(self, hub_url: str, token: str, max_retries: int = DEFAULT_MAX_RETRIES):
        self.base = hub_url.rstrip("/")
        self.max_retries = max_retries
        self.session = requests.Session()
        self.session.headers.update({
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
        })
        self.session.timeout = 30

    def _url(self, path: str) -> str:
        return f"{self.base}{path}"

    def _check(self, resp, context: str) -> dict:
        if resp.status_code >= 400:
            detail = resp.text[:500]
            raise RuntimeError(f"{context} failed (HTTP {resp.status_code}): {detail}")
        data = resp.json()
        if isinstance(data, dict) and data.get("code") not in (None, 0, 200):
            msg = data.get("message") or data.get("msg") or json.dumps(data)
            raise RuntimeError(f"{context} failed: {msg}")
        return data

    def _get(self, path: str, context: str) -> dict:
        return _retry(
            lambda: self._check(self.session.get(self._url(path)), context),
            max_retries=self.max_retries, context=context,
        )

    def _post(self, path: str, payload: dict, context: str) -> dict:
        return _retry(
            lambda: self._check(
                self.session.post(self._url(path), json=payload), context),
            max_retries=self.max_retries, context=context,
        )

    def whoami(self) -> dict:
        return self._get("/api/auth/me", "Auth check")

    def ensure_paper(self, bohrium_paper_id: str, title: str,
                     doi: str = None) -> dict:
        payload = {"bohrium_paper_id": bohrium_paper_id, "title": title}
        if doi:
            payload["doi"] = doi
        return self._post("/api/papers/ensure", payload, "Ensure paper")

    def create_series(self, paper_id: int, title: str,
                      description: str = None) -> dict:
        payload = {"paper_id": paper_id, "title": title}
        if description:
            payload["description"] = description
        return self._post("/api/arm-series", payload, "Create ARM series")

    def create_version(self, series_id: int, version: str) -> dict:
        return self._post(
            f"/api/arm-series/{series_id}/versions",
            {"version": version},
            "Create ARM version",
        )

    def get_upload_credential(self, version_id: int,
                              filename: str = "arm.zip") -> dict:
        return self._post(
            f"/api/arm-versions/{version_id}/upload-credential",
            {"module": "arm", "filename": filename},
            "Get upload credential",
        )

    def complete_upload(self, version_id: int, arm_zip_key: str) -> dict:
        return self._post(
            f"/api/arm-versions/{version_id}/complete",
            {"arm_zip_key": arm_zip_key},
            "Complete upload",
        )

    def get_version(self, version_id: int) -> dict:
        return self._get(f"/api/arm-versions/{version_id}", "Get ARM version")


# ─── OSS Upload ──────────────────────────────────────────────


def upload_to_oss(cred: dict, zip_path: str,
                  max_retries: int = DEFAULT_MAX_RETRIES) -> str:
    """Upload a file to Alibaba Cloud OSS using STS temporary credentials.

    Uses multipart upload for large files (>5 MB), simple put for small ones.
    Returns the object key on success.
    """
    auth = oss2.StsAuth(
        cred["access_key_id"],
        cred["access_key_secret"],
        cred["security_token"],
    )
    bucket = oss2.Bucket(auth, cred["endpoint"], cred["bucket"])
    object_key = cred["object_key"]
    file_size = os.path.getsize(zip_path)

    print(f"  Uploading {_fmt_size(file_size)} to OSS: {object_key}")

    def _do_upload():
        if file_size > MULTIPART_THRESHOLD:
            _multipart_upload(bucket, object_key, zip_path, file_size)
        else:
            with open(zip_path, "rb") as f:
                bucket.put_object(object_key, f)

    _retry(_do_upload, max_retries=max_retries, context="OSS upload")
    print("  Upload complete.")
    return object_key


def _multipart_upload(bucket, key: str, path: str, total_size: int):
    """Resumable multipart upload with progress display."""
    part_size = oss2.determine_part_size(total_size, preferred_size=1024 * 1024)
    upload_id = bucket.init_multipart_upload(key).upload_id
    parts = []
    uploaded = 0

    try:
        with open(path, "rb") as f:
            part_number = 1
            while True:
                chunk = f.read(part_size)
                if not chunk:
                    break
                result = bucket.upload_part(key, upload_id, part_number, chunk)
                parts.append(oss2.models.PartInfo(part_number, result.etag))
                uploaded += len(chunk)
                pct = uploaded * 100 // total_size
                print(f"\r  Progress: {pct}% "
                      f"({_fmt_size(uploaded)}/{_fmt_size(total_size)})",
                      end="", flush=True)
                part_number += 1
        print()
        bucket.complete_multipart_upload(key, upload_id, parts)
    except Exception:
        bucket.abort_multipart_upload(key, upload_id)
        raise


# ─── Helpers ─────────────────────────────────────────────────


def _fmt_size(n: int) -> str:
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024:
            return f"{n:.1f}{unit}"
        n /= 1024
    return f"{n:.1f}TB"


def find_arm_zip(workspace: str) -> str | None:
    """Search for a zip file in the workspace directory.

    Priority: arm.zip > *arm*.zip > first .zip found.
    """
    candidates = glob.glob(os.path.join(workspace, "**", "*.zip"),
                           recursive=True)
    if not candidates:
        return None

    for c in candidates:
        if os.path.basename(c).lower() == "arm.zip":
            return c

    for c in candidates:
        if "arm" in os.path.basename(c).lower():
            return c

    return candidates[0]


def poll_version_status(client: ARMHubClient, version_id: int) -> dict:
    """Poll until ARM version status is terminal (ready / failed)."""
    deadline = time.time() + POLL_TIMEOUT
    while time.time() < deadline:
        v = client.get_version(version_id)
        status = v.get("status", "")
        if status in ("ready", "failed"):
            return v
        print(f"  Processing... (status: {status})")
        time.sleep(POLL_INTERVAL)
    raise TimeoutError(
        f"ARM version {version_id} still processing after {POLL_TIMEOUT}s"
    )


# ─── Main Pipeline ───────────────────────────────────────────


def upload_arm(
    zip_path: str,
    paper_title: str,
    bohrium_paper_id: str,
    hub_url: str = DEFAULT_HUB_URL,
    token: str = DEFAULT_TOKEN,
    series_title: str = None,
    version: str = DEFAULT_VERSION,
    doi: str = None,
    description: str = None,
    max_retries: int = DEFAULT_MAX_RETRIES,
) -> dict:
    """Execute the full ARM upload pipeline. Returns the final ARM version dict."""

    _import_deps()

    if not token:
        raise ValueError(
            "No auth token provided. "
            "Set ARM_HUB_TOKEN in ~/.openclaw/openclaw.json or pass --token."
        )
    if not os.path.isfile(zip_path):
        raise FileNotFoundError(f"ZIP file not found: {zip_path}")

    file_size = os.path.getsize(zip_path)
    print(f"Target: {zip_path} ({_fmt_size(file_size)})")

    client = ARMHubClient(hub_url, token, max_retries=max_retries)

    print("[1/8] Verifying identity...")
    user = client.whoami()
    print(f"  Logged in as: {user.get('display_name', user.get('username'))}")

    print(f"[2/8] Ensuring paper exists: {paper_title[:60]}...")
    paper = client.ensure_paper(bohrium_paper_id, paper_title, doi)
    paper_id = paper["id"]
    print(f"  Paper ID: {paper_id}")

    s_title = series_title or paper_title
    print(f"[3/8] Creating ARM series: {s_title[:60]}...")
    series = client.create_series(paper_id, s_title, description)
    series_id = series["id"]
    print(f"  Series ID: {series_id}")

    print(f"[4/8] Creating ARM version: {version}...")
    ver = client.create_version(series_id, version)
    version_id = ver["id"]
    print(f"  Version ID: {version_id}")

    print("[5/8] Requesting upload credentials...")
    cred = client.get_upload_credential(version_id, "arm.zip")
    print(f"  OSS bucket: {cred['bucket']}, region: {cred.get('region', 'N/A')}")

    print("[6/8] Uploading ARM zip to OSS...")
    object_key = upload_to_oss(cred, zip_path, max_retries=max_retries)

    print("[7/8] Completing upload (triggering extraction)...")
    result = client.complete_upload(version_id, object_key)
    print(f"  Status: {result.get('status')}")

    print("[8/8] Waiting for processing to finish...")
    if result.get("status") == "ready":
        final = client.get_version(version_id)
    else:
        final = poll_version_status(client, version_id)

    status = final.get("status", "unknown")
    arm_url = f"{hub_url}/arm-versions/{version_id}"
    sep = "=" * 50

    if status == "ready":
        print(f"\n{sep}")
        print(f"  Upload successful!")
        print(f"  ARM Version ID : {version_id}")
        print(f"  Status         : {status}")
        print(f"  View at        : {arm_url}")
        print(f"{sep}")
    else:
        err = final.get("error_message", "Unknown error")
        print(f"\n{sep}")
        print(f"  Upload completed but processing failed.")
        print(f"  ARM Version ID : {version_id}")
        print(f"  Status         : {status}")
        print(f"  Error          : {err}")
        print(f"{sep}")

    return final


# ─── CLI ─────────────────────────────────────────────────────


def main():
    parser = argparse.ArgumentParser(
        description="Upload ARM to Paper2ARM Hub",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""\
Examples:
  python upload_arm.py --paper-title "My Paper" --paper-id "abc123"
  python upload_arm.py --zip-path ./arm.zip --paper-title "My Paper" --paper-id "abc123"
""",
    )

    parser.add_argument("--zip-path",
                        help="Path to ARM zip file (auto-detected if omitted)")
    parser.add_argument("--paper-title", required=True, help="Paper title")
    parser.add_argument("--paper-id", required=True, help="Bohrium paper ID")
    parser.add_argument("--series-title",
                        help="ARM series title (defaults to paper title)")
    parser.add_argument("--version", default=DEFAULT_VERSION,
                        help="Version string (default: v1.0)")
    parser.add_argument("--hub-url", default=DEFAULT_HUB_URL,
                        help="ARM Hub URL")
    parser.add_argument("--token", default=DEFAULT_TOKEN,
                        help="Bohrium brmToken")
    parser.add_argument("--doi", help="Paper DOI")
    parser.add_argument("--description", help="ARM series description")
    parser.add_argument("--workspace", default=".",
                        help="Workspace directory to search for zip")
    parser.add_argument("--max-retries", type=int, default=DEFAULT_MAX_RETRIES,
                        help=f"Max retries for API calls (default: {DEFAULT_MAX_RETRIES})")

    args = parser.parse_args()

    zip_path = args.zip_path
    if not zip_path:
        ws = os.path.abspath(args.workspace)
        print(f"No --zip-path specified. Searching workspace: {ws}")
        zip_path = find_arm_zip(args.workspace)
        if not zip_path:
            print("Error: No .zip file found in workspace. "
                  "Use --zip-path to specify.", file=sys.stderr)
            sys.exit(1)
        print(f"Found: {zip_path}")

    try:
        upload_arm(
            zip_path=zip_path,
            paper_title=args.paper_title,
            bohrium_paper_id=args.paper_id,
            hub_url=args.hub_url,
            token=args.token,
            series_title=args.series_title,
            version=args.version,
            doi=args.doi,
            description=args.description,
            max_retries=args.max_retries,
        )
    except Exception as e:
        print(f"\nError: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
