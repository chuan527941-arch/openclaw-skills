---
name: upload-arm
description: "将 ARM 上传到 Paper2ARM Hub。当用户提到'上传 ARM'、'提交 ARM'、'发布复现成果'、'upload arm'时使用。支持 zip 压缩包或 ARM 文件夹（自动压缩）。NOT for：ARM 打包、生成 Dockerfile等"
---

# Upload ARM to ARM Hub

将工作区中的 ARM（Agent Ready Manuscript）上传到 Paper2ARM Hub 平台。

## 前置条件

1. 工作区中存在以下任意一种形式的 ARM：
   - `.zip` 压缩包（优先使用）
   - 名为 `ARM` 的文件夹（将自动压缩为 zip 后上传）
2. 已在 `~/.openclaw/openclaw.json` 中配置 `upload-arm` 和 `bohrium-paper-search` skill 的环境变量

## 认证配置

ARM_HUB_URL 和 ARM_HUB_TOKEN 从 OpenClaw 配置文件 `~/.openclaw/openclaw.json` 中读取：

```json
"upload-arm": {
  "enabled": true,
  "env": {
    "ARM_HUB_URL": "https://arm.bohrium.com",
    "ARM_HUB_TOKEN": "your_brm_token"
  }
}
```

OpenClaw 会自动将配置中的 `env` 变量注入到运行环境。也可在运行时通过 `--hub-url` 和 `--token` 参数覆盖。

## 完整执行流程（Agent 必须严格按顺序执行）

### Step 0: 准备 ARM 压缩包

在开始上传之前，先确认工作区中是否存在可上传的 ARM 包：

1. **优先查找 `.zip` 文件** — 在工作区中搜索 `arm.zip` 或其他 `.zip` 文件
2. **如果没有 zip 但存在 `ARM` 文件夹** — 将其打包为 `arm.zip`：
   ```bash
   cd /path/to/workspace && zip -r arm.zip ARM/
   ```
3. **两者都不存在** — 报错，告知用户缺少 ARM 产物（提醒用户使用file2arm-organization skill 将复现过程打包为ARM，并使用其他arm skill补充md、notebook和dockerfile，再使用当前skill上传至ARM Hub）

### Step 1: 收集上传所需信息

在调用上传脚本之前，Agent 需要确定以下信息：

| 信息 | 如何获取 | 默认值策略 |
|------|----------|------------|
| **paper-title** | 优先使用用户明确提供的标题；否则从 ARM 中的论文文件（如 `README.md`、`metadata.json`）提取 | 必须提供，无法推断时询问用户 |
| **paper-id** (Bohrium 论文 ID) | **必须通过 Step 2 调用 bohrium-paper-search 获取**（见下文） | 无默认值 |
| **series-title** | 用户如有指定则使用；否则默认使用 `paper-title` | 与 paper-title 相同 |
| **description** | 用户如有指定则使用；否则默认生成为：`"ARM reproduction package for: {paper-title}"` | 自动生成 |
| **version** | 用户如有指定则使用 | `v1.0` |
| **doi** | 用户如有提供，或从 ARM 元数据中提取 | 可选 |

**重要原则：** 如果用户在对话中提到了 title、描述、版本号等信息，必须以用户提供的信息为准，而不是使用默认值。

### Step 2: 通过 bohrium-paper-search 检索 Bohrium 论文 ID（必须执行）

`paper-id` 参数是上传的必填字段，**必须**通过 `bohrium-paper-search` 技能获取。具体方法：

1. 读取 `bohrium-paper-search` 技能文档：`~/.openclaw/skills/bohrium-paper-search/SKILL.md`
2. 使用论文标题调用bohrium-paper-search skill搜索接口获取paper-id：
python ~/.openclaw/skills/upload-arm/upload_arm.py \ 
  --paper-title "论文标题" \    
  --paper-id "bohrium_paper_id"
3. 从返回结果中匹配最相关的论文，提取其 Bohrium 论文 ID
4. 如果搜索结果中无法匹配到目标论文，告知用户并请求手动提供 `paper-id`(推荐前往ARM Hub手动上传)

> **注意：** `ACCESS_KEY` 从 `~/.openclaw/openclaw.json` 中 `bohrium-paper-search` skill 的配置获取。

### Step 3: 执行上传

```bash
pip install -r ~/.openclaw/skills/upload-arm/requirements.txt

python ~/.openclaw/skills/upload-arm/upload_arm.py \
  --zip-path /path/to/arm.zip \
  --paper-title "论文标题" \
  --paper-id "bohrium_paper_id" \
  --series-title "系列标题" \
  --description "ARM reproduction package for: 论文标题" \
  --version "v1.0"
```

## 参数说明

| 参数 | 必填 | 默认值 | 说明 |
|------|------|--------|------|
| `--zip-path` | 否 | 自动搜索工作区 | ARM 压缩包路径 |
| `--paper-title` | 是 | - | 论文标题 |
| `--paper-id` | 是 | - | Bohrium 论文 ID（通过 bohrium-paper-search 获取） |
| `--series-title` | 否 | 论文标题 | ARM 系列标题 |
| `--version` | 否 | `v1.0` | 版本号 |
| `--hub-url` | 否 | 环境变量 `ARM_HUB_URL` | ARM Hub 地址 |
| `--token` | 否 | 环境变量 `ARM_HUB_TOKEN` | Bohrium Token |
| `--doi` | 否 | - | 论文 DOI |
| `--description` | 否 | - | ARM 系列描述 |
| `--workspace` | 否 | 当前目录 | 搜索 zip 文件的工作区路径 |
| `--max-retries` | 否 | `3` | API 请求失败时的最大重试次数 |

## 上传脚本内部流程

1. **查找 ARM 包** — 在工作区中定位 `.zip` 文件（优先 `arm.zip`）
2. **身份验证** — 使用 brmToken 验证身份
3. **论文落库** — 确保目标论文在 ARM Hub 中存在
4. **创建 ARM Series** — 为该论文创建复现系列
5. **创建 ARM Version** — 在系列下创建新版本
6. **获取上传凭证** — 从 ARM Hub 获取 OSS STS 临时凭证
7. **上传到 OSS** — 通过阿里云 OSS SDK 直传（大文件自动分片上传）
8. **完成上传** — 通知 ARM Hub 触发解压处理
9. **等待处理** — 轮询状态直到 `ready` 或 `failed`

## 输出

上传成功后返回：
- ARM Version ID
- ARM Hub 上的访问链接
- 处理状态（ready / failed）

## 常见错误与排查

| 问题 | 原因 | 解决 |
|------|------|------|
| `No auth token provided` | 未配置 ARM_HUB_TOKEN | 在 openclaw.json 的 upload-arm env 中配置 |
| `No .zip file found` | 工作区中没有 zip 文件 | 检查是否有 ARM 文件夹可以压缩，或用 `--zip-path` 指定 |
| `HTTP 401` | Token 过期或无效 | 更新 ARM_HUB_TOKEN |
| `HTTP 5xx` / 网络超时 | 服务端或网络异常 | 脚本会自动重试，也可增大 `--max-retries` |
| OSS 上传失败 | 凭证过期或网络不稳定 | 重新运行脚本，STS 凭证会重新获取 |
| bohrium-paper-search 无结果 | 关键词不匹配或论文未收录 | 尝试调整关键词，或让用户手动提供 paper-id |
