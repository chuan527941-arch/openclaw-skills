#!/usr/bin/env python3
"""Upload Dataset to Paper2ARM Hub.

Pipeline: find/create zip → auth → create dataset → get STS credentials
→ upload to OSS → complete.
"""

import argparse
import glob
import json
import os
import subprocess
import sys
import time

# ─── Defaults ────────────────────────────────────────────────

DEFAULT_HUB_URL = os.environ.get("ARM_HUB_URL", "http://47.92.172.133:50005")
DEFAULT_TOKEN = os.environ.get("ARM_HUB_TOKEN", "")
MULTIPART_THRESHOLD = 5 * 1024 * 1024  # 5 MB


def _import_deps():
    """Import third-party deps at call time so --help works without them."""
    global requests, oss2
    try:
        import requests as _requests
        import oss2 as _oss2
    except ImportError as e:
        print(f"Missing dependency: {e.name}", file=sys.stderr)
        print("Run: pip install oss2 requests", file=sys.stderr)
        sys.exit(1)
    requests = _requests
    oss2 = _oss2


class ARMHubClient:
    """Thin wrapper around ARM Hub REST API for Dataset operations."""

    def __init__(self, hub_url: str, token: str, max_retries: int = 3):
        self.base = hub_url.rstrip("/")
        self.max_retries = max_retries
        self.session = requests.Session()
        self.session.headers.update({
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
        })

    def _url(self, path: str) -> str:
        return f"{self.base}{path}"

    def _request(self, method: str, path: str, context: str, **kwargs) -> dict:
        for attempt in range(1, self.max_retries + 1):
            try:
                resp = self.session.request(method, self._url(path), **kwargs)
                if resp.status_code >= 500 and attempt < self.max_retries:
                    wait = 2 ** attempt
                    print(f"  Server error (HTTP {resp.status_code}), retrying in {wait}s...")
                    time.sleep(wait)
                    continue
                if resp.status_code >= 400:
                    detail = resp.text[:500]
                    raise RuntimeError(f"{context} failed (HTTP {resp.status_code}): {detail}")
                return resp.json()
            except requests.ConnectionError:
                if attempt < self.max_retries:
                    wait = 2 ** attempt
                    print(f"  Connection error, retrying in {wait}s...")
                    time.sleep(wait)
                else:
                    raise
        return {}

    # ── Auth ─────────────────────────────────────────────────

    def whoami(self) -> dict:
        return self._request("GET", "/api/auth/me", "Auth check")

    # ── Dataset ──────────────────────────────────────────────

    def create_dataset(self, name: str, description: str = None) -> dict:
        payload = {"name": name}
        if description:
            payload["description"] = description
        return self._request("POST", "/api/datasets", "Create dataset", json=payload)

    def get_upload_credential(self, dataset_id: int) -> dict:
        return self._request(
            "POST",
            f"/api/datasets/{dataset_id}/upload-credential",
            "Get upload credential",
        )

    def complete_upload(self, dataset_id: int, oss_key: str,
                        size_bytes: int = 0) -> dict:
        params = {"oss_key": oss_key, "size_bytes": size_bytes}
        return self._request(
            "POST",
            f"/api/datasets/{dataset_id}/complete",
            "Complete upload",
            params=params,
        )


# ─── OSS Upload ──────────────────────────────────────────────

def upload_to_oss(cred: dict, zip_path: str) -> str:
    """Upload a file to Alibaba Cloud OSS using STS temporary credentials."""
    auth = oss2.StsAuth(
        cred["access_key_id"],
        cred["access_key_secret"],
        cred["security_token"],
    )
    bucket = oss2.Bucket(auth, cred["endpoint"], cred["bucket"])
    object_key = cred["object_key"]
    file_size = os.path.getsize(zip_path)

    print(f"  Uploading {_fmt_size(file_size)} to OSS: {object_key}")

    if file_size > MULTIPART_THRESHOLD:
        _multipart_upload(bucket, object_key, zip_path, file_size)
    else:
        with open(zip_path, "rb") as f:
            bucket.put_object(object_key, f)

    print("  Upload complete.")
    return object_key


def _multipart_upload(bucket, key: str, path: str, total_size: int):
    """Resumable multipart upload with progress display."""
    part_size = oss2.determine_part_size(total_size, preferred_size=1024 * 1024)
    upload_id = bucket.init_multipart_upload(key).upload_id
    parts = []
    uploaded = 0

    try:
        with open(path, "rb") as f:
            part_number = 1
            while True:
                chunk = f.read(part_size)
                if not chunk:
                    break
                result = bucket.upload_part(key, upload_id, part_number, chunk)
                parts.append(oss2.models.PartInfo(part_number, result.etag))
                uploaded += len(chunk)
                pct = uploaded * 100 // total_size
                print(
                    f"\r  Progress: {pct}% ({_fmt_size(uploaded)}/{_fmt_size(total_size)})",
                    end="", flush=True,
                )
                part_number += 1
        print()
        bucket.complete_multipart_upload(key, upload_id, parts)
    except Exception:
        bucket.abort_multipart_upload(key, upload_id)
        raise


# ─── Helpers ─────────────────────────────────────────────────

def _fmt_size(n: int) -> str:
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024:
            return f"{n:.1f}{unit}"
        n /= 1024
    return f"{n:.1f}TB"


def find_dataset_zip(workspace: str) -> str | None:
    """Search for a dataset zip file in the workspace.

    Priority: dataset.zip > *dataset*.zip > first .zip found.
    """
    candidates = glob.glob(os.path.join(workspace, "**", "*.zip"), recursive=True)
    if not candidates:
        return None

    for c in candidates:
        if os.path.basename(c).lower() == "dataset.zip":
            return c

    for c in candidates:
        if "dataset" in os.path.basename(c).lower():
            return c

    return candidates[0]


def zip_folder(folder_path: str, output_path: str = None) -> str:
    """Compress a folder into a zip file. Returns the zip file path."""
    folder_path = os.path.abspath(folder_path)
    if not os.path.isdir(folder_path):
        raise FileNotFoundError(f"Folder not found: {folder_path}")

    if output_path is None:
        output_path = os.path.join(
            os.path.dirname(folder_path), "dataset.zip"
        )

    folder_name = os.path.basename(folder_path)
    parent_dir = os.path.dirname(folder_path)

    print(f"  Compressing folder '{folder_name}' → {output_path}")
    subprocess.run(
        ["zip", "-r", output_path, folder_name],
        cwd=parent_dir,
        check=True,
        capture_output=True,
    )
    print(f"  Compressed: {_fmt_size(os.path.getsize(output_path))}")
    return output_path


# ─── Main Pipeline ───────────────────────────────────────────

def upload_dataset(
    zip_path: str,
    name: str,
    hub_url: str = DEFAULT_HUB_URL,
    token: str = DEFAULT_TOKEN,
    description: str = None,
) -> dict:
    """Execute the full Dataset upload pipeline."""

    _import_deps()

    if not token:
        raise ValueError(
            "No auth token provided. Set ARM_HUB_TOKEN env var or pass --token."
        )
    if not os.path.isfile(zip_path):
        raise FileNotFoundError(f"ZIP file not found: {zip_path}")

    file_size = os.path.getsize(zip_path)
    client = ARMHubClient(hub_url, token)

    # Step 1: Verify auth
    print("[1/5] Verifying identity...")
    user = client.whoami()
    print(f"  Logged in as: {user.get('display_name', user.get('username'))}")

    # Step 2: Create Dataset
    desc = description or f"Dataset: {name}"
    print(f"[2/5] Creating dataset: {name}...")
    dataset = client.create_dataset(name, desc)
    dataset_id = dataset["id"]
    print(f"  Dataset ID: {dataset_id}")

    # Step 3: Get STS upload credential
    print("[3/5] Requesting upload credentials...")
    cred = client.get_upload_credential(dataset_id)
    print(f"  OSS bucket: {cred['bucket']}, region: {cred['region']}")

    # Step 4: Upload to OSS
    print("[4/5] Uploading dataset zip to OSS...")
    object_key = upload_to_oss(cred, zip_path)

    # Step 5: Complete upload
    print("[5/5] Completing upload...")
    result = client.complete_upload(dataset_id, object_key, file_size)

    dataset_url = f"{hub_url}/datasets/{dataset_id}"
    print(f"\n{'='*50}")
    print(f"  Upload successful!")
    print(f"  Dataset ID   : {dataset_id}")
    print(f"  Name         : {name}")
    print(f"  Size         : {_fmt_size(file_size)}")
    print(f"  View at      : {dataset_url}")
    print(f"{'='*50}")

    return result


# ─── CLI ─────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="Upload Dataset to Paper2ARM Hub",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Upload with explicit zip path
  python upload_dataset.py --zip-path ./dataset.zip --name "My Dataset"

  # Upload a folder (auto-compress)
  python upload_dataset.py --folder ./data --name "My Dataset"

  # Auto-detect zip in workspace
  python upload_dataset.py --name "My Dataset"

  # Full options
  python upload_dataset.py \\
    --zip-path ./dataset.zip \\
    --name "My Dataset" \\
    --description "Training data for model X" \\
    --hub-url "http://47.92.172.133:50005" \\
    --token "your_brm_token"
        """,
    )

    parser.add_argument("--zip-path", help="Path to dataset zip file")
    parser.add_argument("--folder", help="Path to dataset folder (will be auto-compressed)")
    parser.add_argument("--name", required=True, help="Dataset name")
    parser.add_argument("--description", help="Dataset description")
    parser.add_argument("--hub-url", default=DEFAULT_HUB_URL, help="ARM Hub URL")
    parser.add_argument("--token", default=DEFAULT_TOKEN, help="Bohrium brmToken")
    parser.add_argument("--workspace", default=".", help="Workspace to search for zip")
    parser.add_argument("--max-retries", type=int, default=3, help="Max API retries")

    args = parser.parse_args()

    # Resolve zip path
    zip_path = args.zip_path

    if not zip_path and args.folder:
        zip_path = zip_folder(args.folder)

    if not zip_path:
        print(f"No --zip-path or --folder specified. Searching workspace: {os.path.abspath(args.workspace)}")
        zip_path = find_dataset_zip(args.workspace)
        if not zip_path:
            print(
                "Error: No .zip file found in workspace. "
                "Use --zip-path or --folder to specify.",
                file=sys.stderr,
            )
            sys.exit(1)
        print(f"Found: {zip_path}")

    try:
        upload_dataset(
            zip_path=zip_path,
            name=args.name,
            hub_url=args.hub_url,
            token=args.token,
            description=args.description,
        )
    except Exception as e:
        print(f"\nError: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
