---
name: upload-dataset
description: "将 Dataset 压缩包上传到 ARM Hub。当用户提到'上传数据集'、'上传 dataset'、'提交数据集'、'upload dataset'时使用。支持 zip 压缩包或指定文件夹（自动压缩）。NOT for：ARM 上传、Skill 上传"
---

# Upload Dataset to ARM Hub

将工作区中的 Dataset 压缩包上传到 Paper2ARM Hub 平台。

## 前置条件

1. 工作区中存在以下任意一种形式的 Dataset：
   - `.zip` 压缩包（优先使用）
   - 指定的数据集文件夹（将自动压缩为 zip 后上传）
2. 已在 `~/.openclaw/openclaw.json` 中配置 `upload-dataset` skill 的环境变量

## 认证配置

ARM_HUB_URL 和 ARM_HUB_TOKEN 从 OpenClaw 配置文件 `~/.openclaw/openclaw.json` 中读取：

```json
"upload-dataset": {
  "enabled": true,
  "env": {
    "ARM_HUB_URL": "https://arm.bohrium.com",
    "ARM_HUB_TOKEN": "your_brm_token"
  }
}
```

OpenClaw 会自动将配置中的 `env` 变量注入到运行环境。也可在运行时通过 `--hub-url` 和 `--token` 参数覆盖。

## 完整执行流程（Agent 必须严格按顺序执行）

### Step 0: 准备 Dataset 压缩包

在开始上传之前，先确认工作区中是否存在可上传的数据集：

1. **用户指定了 `--zip-path`** — 直接使用指定的 zip 文件
2. **用户指定了 `--folder`** — 将文件夹打包为 `dataset.zip`：
   ```bash
   cd /path/to/workspace && zip -r dataset.zip <folder_name>/
   ```
3. **自动搜索工作区** — 查找 `dataset.zip` 或包含 `dataset` 关键字的 `.zip` 文件
4. **都不存在** — 报错，告知用户缺少数据集文件，请先准备好数据集并压缩为 zip

### Step 1: 收集上传所需信息

在调用上传脚本之前，Agent 需要确定以下信息：

| 信息 | 如何获取 | 默认值策略 |
|------|----------|------------|
| **name** | 优先使用用户明确提供的名称；否则从 zip 文件名推断 | 必须提供，无法推断时询问用户 |
| **description** | 用户如有指定则使用；否则默认生成为：`"Dataset: {name}"` | 自动生成 |

**重要原则：** 如果用户在对话中提到了名称、描述等信息，必须以用户提供的信息为准，而不是使用默认值。

### Step 2: 执行上传

```bash
pip install -r ~/.openclaw/skills/upload-dataset/requirements.txt

python ~/.openclaw/skills/upload-dataset/upload_dataset.py \
  --zip-path /path/to/dataset.zip \
  --name "数据集名称" \
  --description "数据集描述"
```

或者直接指定文件夹（脚本会自动压缩）：

```bash
python ~/.openclaw/skills/upload-dataset/upload_dataset.py \
  --folder /path/to/dataset_folder \
  --name "数据集名称"
```

## 参数说明

| 参数 | 必填 | 默认值 | 说明 |
|------|------|--------|------|
| `--zip-path` | 否 | 自动搜索工作区 | Dataset 压缩包路径（与 `--folder` 二选一） |
| `--folder` | 否 | - | 数据集文件夹路径（自动压缩为 zip） |
| `--name` | 是 | - | 数据集名称 |
| `--description` | 否 | - | 数据集描述 |
| `--hub-url` | 否 | 环境变量 `ARM_HUB_URL` | ARM Hub 地址 |
| `--token` | 否 | 环境变量 `ARM_HUB_TOKEN` | Bohrium Token |
| `--workspace` | 否 | 当前目录 | 搜索 zip 文件的工作区路径 |
| `--max-retries` | 否 | `3` | API 请求失败时的最大重试次数 |

## 上传脚本内部流程

1. **定位 Dataset 包** — 在工作区中定位 `.zip` 文件，或将指定文件夹压缩为 zip
2. **身份验证** — 使用 brmToken 验证身份
3. **创建 Dataset** — 在 ARM Hub 中创建 Dataset 记录
4. **获取上传凭证** — 从 ARM Hub 获取 OSS STS 临时凭证
5. **上传到 OSS** — 通过阿里云 OSS SDK 直传（大文件自动分片上传）
6. **完成上传** — 通知 ARM Hub 记录上传结果

## 输出

上传成功后返回：
- Dataset ID
- ARM Hub 上的访问链接
- 文件大小

## 常见错误与排查

| 问题 | 原因 | 解决 |
|------|------|------|
| `No auth token provided` | 未配置 ARM_HUB_TOKEN | 在 openclaw.json 的 upload-dataset env 中配置 |
| `No .zip file found` | 工作区中没有 zip 文件 | 使用 `--zip-path` 或 `--folder` 指定数据集位置 |
| `HTTP 401` | Token 过期或无效 | 更新 ARM_HUB_TOKEN |
| `HTTP 5xx` / 网络超时 | 服务端或网络异常 | 脚本会自动重试，也可增大 `--max-retries` |
| OSS 上传失败 | 凭证过期或网络不稳定 | 重新运行脚本，STS 凭证会重新获取 |
