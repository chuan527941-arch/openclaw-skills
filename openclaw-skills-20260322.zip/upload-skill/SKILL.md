---
name: upload-skill
description: "将 Skill 文件夹上传到 ARM Hub。当用户提到'上传技能'、'上传 skill'、'提交 skill'、'发布 skill'、'upload skill'时使用。从 ~/.openclaw/skills/ 目录中选择 Skill 文件夹并上传。NOT for：ARM 上传、Dataset 上传"
---

# Upload Skill to ARM Hub

将用户本地的 Skill 文件夹上传到 Paper2ARM Hub 平台。

## 前置条件

1. `~/.openclaw/skills/` 目录下存在至少一个 Skill 文件夹
2. 已在 `~/.openclaw/openclaw.json` 中配置 `upload-skill` skill 的环境变量

## 认证配置

ARM_HUB_URL 和 ARM_HUB_TOKEN 从 OpenClaw 配置文件 `~/.openclaw/openclaw.json` 中读取：

```json
"upload-skill": {
  "enabled": true,
  "env": {
    "ARM_HUB_URL": "https://arm.bohrium.com",
    "ARM_HUB_TOKEN": "your_brm_token"
  }
}
```

OpenClaw 会自动将配置中的 `env` 变量注入到运行环境。也可在运行时通过 `--hub-url` 和 `--token` 参数覆盖。

## 完整执行流程（Agent 必须严格按顺序执行）

### Step 0: 列出可用的 Skill 并让用户确认

**这一步是必须的，Agent 不能跳过。**

1. 运行列出命令，展示 `~/.openclaw/skills/` 下所有可用的 Skill：
   ```bash
   python ~/.openclaw/skills/upload-skill/upload_skill.py --list
   ```
   输出示例：
   ```
   Available skills in /Users/xxx/.openclaw/skills/:
     [1] bohrium-paper-search    (has SKILL.md)
     [2] upload-arm              (has SKILL.md)
     [3] my-custom-skill         (has README.md)
   ```

2. **将列表展示给用户，询问用户要上传哪个 Skill**
3. 用户确认后，使用对应的文件夹名作为 `--folder` 参数

> **重要：** 绝对不能自行决定上传哪个 Skill，必须等待用户明确指定。

### Step 1: 收集上传所需信息

在调用上传脚本之前，Agent 需要确定以下信息：

| 信息 | 如何获取 | 默认值策略 |
|------|----------|------------|
| **name** | 优先使用用户明确提供的名称；否则使用 Skill 文件夹名 | 文件夹名 |
| **description** | 用户如有指定则使用；否则自动从 SKILL.md / README.md 提取，或生成默认描述 | 自动生成 |
| **tags** | 用户如有指定则使用 | 可选 |
| **version** | 用户如有指定则使用 | 可选 |

**重要原则：** 如果用户在对话中提到了名称、描述、标签等信息，必须以用户提供的信息为准，而不是使用默认值。

### Step 2: 执行上传

```bash
pip install -r ~/.openclaw/skills/upload-skill/requirements.txt

python ~/.openclaw/skills/upload-skill/upload_skill.py \
  --folder <skill_folder_name> \
  --name "技能名称" \
  --description "技能描述" \
  --tags "tag1,tag2" \
  --version "v1.0"
```

`--folder` 支持两种写法：
- **仅文件夹名**：自动在 `~/.openclaw/skills/` 下查找，如 `--folder my-skill`
- **完整路径**：使用绝对路径，如 `--folder /path/to/my-skill`

## 参数说明

| 参数 | 必填 | 默认值 | 说明 |
|------|------|--------|------|
| `--list` | 否 | - | 列出 `~/.openclaw/skills/` 下所有可用 Skill |
| `--folder` | 是 | - | Skill 文件夹名或路径 |
| `--name` | 否 | 文件夹名 | 技能名称 |
| `--description` | 否 | - | 技能描述 |
| `--tags` | 否 | - | 标签（逗号分隔） |
| `--version` | 否 | - | 版本号 |
| `--hub-url` | 否 | 环境变量 `ARM_HUB_URL` | ARM Hub 地址 |
| `--token` | 否 | 环境变量 `ARM_HUB_TOKEN` | Bohrium Token |
| `--skills-dir` | 否 | `~/.openclaw/skills` | Skill 目录的根路径 |
| `--max-retries` | 否 | `3` | API 请求失败时的最大重试次数 |

## 上传脚本内部流程

1. **定位 Skill 文件夹** — 在 `~/.openclaw/skills/` 下找到目标文件夹
2. **身份验证** — 使用 brmToken 验证身份
3. **创建 Skill** — 在 ARM Hub 中创建 Skill 记录
4. **获取上传凭证** — 从 ARM Hub 获取 OSS STS 临时凭证
5. **上传 zip 到 OSS** — 通过阿里云 OSS SDK 直传（大文件自动分片上传）
6. **上传 md 到 OSS**（如检测到） — 单独上传文档
7. **完成上传** — 通知 ARM Hub 记录上传结果

## Skill 文件夹结构建议

```
~/.openclaw/skills/
├── my-skill/
│   ├── SKILL.md          # 技能文档（推荐，会被自动检测并单独上传）
│   ├── requirements.txt  # Python 依赖
│   ├── main.py           # 主要脚本
│   └── ...               # 其他文件
├── another-skill/
│   └── ...
```

> 无格式要求，任何文件均可上传。直接将指定Skill的整个文件夹上传即可

## 输出

上传成功后返回：
- 是否成功
- ARM Hub 上的访问链接

## 常见错误与排查

| 问题 | 原因 | 解决 |
|------|------|------|
| `No auth token provided` | 未配置 ARM_HUB_TOKEN | 在 openclaw.json 的 upload-skill env 中配置 |
| `No skills found` | `~/.openclaw/skills/` 下没有文件夹 | 先将 Skill 文件夹放到该目录 |
| `Skill folder not found` | 指定的文件夹名不存在 | 运行 `--list` 查看可用的 Skill |
| `HTTP 401` | Token 过期或无效 | 更新 ARM_HUB_TOKEN |
| `HTTP 5xx` / 网络超时 | 服务端或网络异常 | 脚本会自动重试，也可增大 `--max-retries` |
| OSS 上传失败 | 凭证过期或网络不稳定 | 重新运行脚本，STS 凭证会重新获取 |
