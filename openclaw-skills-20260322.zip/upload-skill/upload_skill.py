#!/usr/bin/env python3
"""Upload Skill to Paper2ARM Hub.

Pipeline: find/create zip → detect md → auth → create skill → get STS
→ upload zip to OSS → upload md to OSS → complete.
"""

import argparse
import glob
import os
import subprocess
import sys
import time

# ─── Defaults ────────────────────────────────────────────────

DEFAULT_HUB_URL = os.environ.get("ARM_HUB_URL", "http://47.92.172.133:50005")
DEFAULT_TOKEN = os.environ.get("ARM_HUB_TOKEN", "")
MULTIPART_THRESHOLD = 5 * 1024 * 1024  # 5 MB
MD_CANDIDATES = ("SKILL.md", "README.md", "skill.md", "readme.md")


def _import_deps():
    """Import third-party deps at call time so --help works without them."""
    global requests, oss2
    try:
        import requests as _requests
        import oss2 as _oss2
    except ImportError as e:
        print(f"Missing dependency: {e.name}", file=sys.stderr)
        print("Run: pip install oss2 requests", file=sys.stderr)
        sys.exit(1)
    requests = _requests
    oss2 = _oss2


class ARMHubClient:
    """Thin wrapper around ARM Hub REST API for Skill operations."""

    def __init__(self, hub_url: str, token: str, max_retries: int = 3):
        self.base = hub_url.rstrip("/")
        self.max_retries = max_retries
        self.session = requests.Session()
        self.session.headers.update({
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
        })

    def _url(self, path: str) -> str:
        return f"{self.base}{path}"

    def _request(self, method: str, path: str, context: str, **kwargs) -> dict:
        for attempt in range(1, self.max_retries + 1):
            try:
                resp = self.session.request(method, self._url(path), **kwargs)
                if resp.status_code >= 500 and attempt < self.max_retries:
                    wait = 2 ** attempt
                    print(f"  Server error (HTTP {resp.status_code}), retrying in {wait}s...")
                    time.sleep(wait)
                    continue
                if resp.status_code >= 400:
                    detail = resp.text[:500]
                    raise RuntimeError(f"{context} failed (HTTP {resp.status_code}): {detail}")
                return resp.json()
            except requests.ConnectionError:
                if attempt < self.max_retries:
                    wait = 2 ** attempt
                    print(f"  Connection error, retrying in {wait}s...")
                    time.sleep(wait)
                else:
                    raise
        return {}

    # ── Auth ─────────────────────────────────────────────────

    def whoami(self) -> dict:
        return self._request("GET", "/api/auth/me", "Auth check")

    # ── Skill ────────────────────────────────────────────────

    def create_skill(self, name: str, description: str = None,
                     tags: str = None, version: str = None) -> dict:
        payload = {"name": name}
        if description:
            payload["description"] = description
        if tags:
            payload["tags"] = tags
        if version:
            payload["version"] = version
        return self._request("POST", "/api/skills", "Create skill", json=payload)

    def get_upload_credential(self, skill_id: int) -> dict:
        return self._request(
            "POST",
            f"/api/skills/{skill_id}/upload-credential",
            "Get upload credential",
        )

    def complete_upload(self, skill_id: int, oss_zip_key: str = None,
                        oss_md_key: str = None) -> dict:
        params = {}
        if oss_zip_key:
            params["oss_zip_key"] = oss_zip_key
        if oss_md_key:
            params["oss_md_key"] = oss_md_key
        return self._request(
            "POST",
            f"/api/skills/{skill_id}/complete",
            "Complete upload",
            params=params,
        )


# ─── OSS Upload ──────────────────────────────────────────────

def upload_to_oss(cred_info: dict, file_path: str, object_key: str) -> str:
    """Upload a file to Alibaba Cloud OSS using STS temporary credentials."""
    auth = oss2.StsAuth(
        cred_info["access_key_id"],
        cred_info["access_key_secret"],
        cred_info["security_token"],
    )
    bucket = oss2.Bucket(auth, cred_info["endpoint"], cred_info["bucket"])
    file_size = os.path.getsize(file_path)

    print(f"  Uploading {_fmt_size(file_size)} to OSS: {object_key}")

    if file_size > MULTIPART_THRESHOLD:
        _multipart_upload(bucket, object_key, file_path, file_size)
    else:
        with open(file_path, "rb") as f:
            bucket.put_object(object_key, f)

    print("  Upload complete.")
    return object_key


def _multipart_upload(bucket, key: str, path: str, total_size: int):
    """Resumable multipart upload with progress display."""
    part_size = oss2.determine_part_size(total_size, preferred_size=1024 * 1024)
    upload_id = bucket.init_multipart_upload(key).upload_id
    parts = []
    uploaded = 0

    try:
        with open(path, "rb") as f:
            part_number = 1
            while True:
                chunk = f.read(part_size)
                if not chunk:
                    break
                result = bucket.upload_part(key, upload_id, part_number, chunk)
                parts.append(oss2.models.PartInfo(part_number, result.etag))
                uploaded += len(chunk)
                pct = uploaded * 100 // total_size
                print(
                    f"\r  Progress: {pct}% ({_fmt_size(uploaded)}/{_fmt_size(total_size)})",
                    end="", flush=True,
                )
                part_number += 1
        print()
        bucket.complete_multipart_upload(key, upload_id, parts)
    except Exception:
        bucket.abort_multipart_upload(key, upload_id)
        raise


# ─── Helpers ─────────────────────────────────────────────────

def _fmt_size(n: int) -> str:
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024:
            return f"{n:.1f}{unit}"
        n /= 1024
    return f"{n:.1f}TB"


def find_skill_zip(workspace: str) -> str | None:
    """Search for a skill zip file in the workspace.

    Priority: skill.zip > *skill*.zip > first .zip found.
    """
    candidates = glob.glob(os.path.join(workspace, "**", "*.zip"), recursive=True)
    if not candidates:
        return None

    for c in candidates:
        if os.path.basename(c).lower() == "skill.zip":
            return c

    for c in candidates:
        if "skill" in os.path.basename(c).lower():
            return c

    return candidates[0]


def find_md_in_folder(folder_path: str) -> str | None:
    """Find a markdown doc in a skill folder.

    Priority: SKILL.md > README.md (case-insensitive).
    """
    if not os.path.isdir(folder_path):
        return None

    entries = os.listdir(folder_path)
    entry_lower_map = {e.lower(): e for e in entries}

    for candidate in MD_CANDIDATES:
        real_name = entry_lower_map.get(candidate.lower())
        if real_name:
            return os.path.join(folder_path, real_name)

    for e in entries:
        if e.lower().endswith(".md"):
            return os.path.join(folder_path, e)

    return None


def find_md_near_zip(zip_path: str) -> str | None:
    """Find a markdown doc in the same directory as the zip file."""
    return find_md_in_folder(os.path.dirname(zip_path))


def zip_folder(folder_path: str, output_path: str = None) -> str:
    """Compress a folder into a zip file. Returns the zip file path."""
    folder_path = os.path.abspath(folder_path)
    if not os.path.isdir(folder_path):
        raise FileNotFoundError(f"Folder not found: {folder_path}")

    if output_path is None:
        output_path = os.path.join(
            os.path.dirname(folder_path), "skill.zip"
        )

    folder_name = os.path.basename(folder_path)
    parent_dir = os.path.dirname(folder_path)

    print(f"  Compressing folder '{folder_name}' → {output_path}")
    subprocess.run(
        ["zip", "-r", output_path, folder_name],
        cwd=parent_dir,
        check=True,
        capture_output=True,
    )
    print(f"  Compressed: {_fmt_size(os.path.getsize(output_path))}")
    return output_path


# ─── Main Pipeline ───────────────────────────────────────────

def upload_skill(
    zip_path: str = None,
    md_path: str = None,
    name: str = "",
    hub_url: str = DEFAULT_HUB_URL,
    token: str = DEFAULT_TOKEN,
    description: str = None,
    tags: str = None,
    version: str = None,
) -> dict:
    """Execute the full Skill upload pipeline."""

    _import_deps()

    if not token:
        raise ValueError(
            "No auth token provided. Set ARM_HUB_TOKEN env var or pass --token."
        )
    if not zip_path and not md_path:
        raise ValueError("At least one of --zip-path or --md-path must be provided.")
    if zip_path and not os.path.isfile(zip_path):
        raise FileNotFoundError(f"ZIP file not found: {zip_path}")
    if md_path and not os.path.isfile(md_path):
        raise FileNotFoundError(f"Markdown file not found: {md_path}")

    has_zip = zip_path is not None
    has_md = md_path is not None
    total_steps = 4 + int(has_zip) + int(has_md)
    step = 0

    client = ARMHubClient(hub_url, token)

    # Step 1: Verify auth
    step += 1
    print(f"[{step}/{total_steps}] Verifying identity...")
    user = client.whoami()
    print(f"  Logged in as: {user.get('display_name', user.get('username'))}")

    # Step 2: Create Skill
    step += 1
    print(f"[{step}/{total_steps}] Creating skill: {name}...")
    skill = client.create_skill(name, description, tags, version)
    skill_id = skill["id"]
    print(f"  Skill ID: {skill_id}")

    # Step 3: Get STS upload credential
    step += 1
    print(f"[{step}/{total_steps}] Requesting upload credentials...")
    cred = client.get_upload_credential(skill_id)
    print(f"  OSS bucket: {cred['bucket']}, region: {cred['region']}")

    # Step 4: Upload zip to OSS (if present)
    oss_zip_key = None
    if has_zip:
        step += 1
        print(f"[{step}/{total_steps}] Uploading skill zip to OSS...")
        oss_zip_key = upload_to_oss(cred, zip_path, cred["zip_object_key"])

    # Step 5: Upload md to OSS (if present)
    oss_md_key = None
    if has_md:
        step += 1
        print(f"[{step}/{total_steps}] Uploading skill document to OSS...")
        oss_md_key = upload_to_oss(cred, md_path, cred["md_object_key"])

    # Step 6: Complete upload
    step += 1
    print(f"[{step}/{total_steps}] Completing upload...")
    result = client.complete_upload(skill_id, oss_zip_key, oss_md_key)

    skill_url = f"{hub_url}/skills/{skill_id}"
    print(f"\n{'='*50}")
    print(f"  Upload successful!")
    print(f"  Skill ID     : {skill_id}")
    print(f"  Name         : {name}")
    if has_zip:
        print(f"  Zip          : {os.path.basename(zip_path)} ({_fmt_size(os.path.getsize(zip_path))})")
    if has_md:
        print(f"  Document     : {os.path.basename(md_path)}")
    print(f"  View at      : {skill_url}")
    print(f"{'='*50}")

    return result


# ─── CLI ─────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="Upload Skill to Paper2ARM Hub",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Upload a skill folder (auto-compress + detect SKILL.md)
  python upload_skill.py --folder ./my-skill --name "My Skill"

  # Upload with explicit zip path
  python upload_skill.py --zip-path ./skill.zip --name "My Skill"

  # Upload zip + separate markdown
  python upload_skill.py --zip-path ./skill.zip --md-path ./SKILL.md --name "My Skill"

  # Upload only a markdown document (no zip)
  python upload_skill.py --md-path ./SKILL.md --name "My Skill"

  # Full options
  python upload_skill.py \\
    --folder ./my-skill \\
    --name "My Skill" \\
    --description "A skill for ..." \\
    --tags "python,ml" \\
    --version "v1.0" \\
    --hub-url "http://47.92.172.133:50005" \\
    --token "your_brm_token"
        """,
    )

    parser.add_argument("--zip-path", help="Path to skill zip file")
    parser.add_argument("--folder", help="Path to skill folder (auto-compress + detect md)")
    parser.add_argument("--md-path", help="Path to skill markdown doc (SKILL.md / README.md)")
    parser.add_argument("--name", required=True, help="Skill name")
    parser.add_argument("--description", help="Skill description")
    parser.add_argument("--tags", help="Comma-separated tags")
    parser.add_argument("--version", help="Version string")
    parser.add_argument("--hub-url", default=DEFAULT_HUB_URL, help="ARM Hub URL")
    parser.add_argument("--token", default=DEFAULT_TOKEN, help="Bohrium brmToken")
    parser.add_argument("--workspace", default=".", help="Workspace to search for files")
    parser.add_argument("--max-retries", type=int, default=3, help="Max API retries")

    args = parser.parse_args()

    zip_path = args.zip_path
    md_path = args.md_path

    # If folder is specified, compress it and detect md
    if args.folder:
        folder = os.path.abspath(args.folder)
        if not zip_path:
            zip_path = zip_folder(folder)
        if not md_path:
            md_path = find_md_in_folder(folder)
            if md_path:
                print(f"Detected document: {md_path}")

    # Auto-search workspace if nothing specified
    if not zip_path and not md_path:
        print(f"No --zip-path, --folder, or --md-path specified. Searching workspace: {os.path.abspath(args.workspace)}")
        zip_path = find_skill_zip(args.workspace)
        if zip_path:
            print(f"Found zip: {zip_path}")
            if not md_path:
                md_path = find_md_near_zip(zip_path)
                if md_path:
                    print(f"Found document: {md_path}")

    if not zip_path and not md_path:
        print(
            "Error: No skill files found. "
            "Use --zip-path, --folder, or --md-path to specify.",
            file=sys.stderr,
        )
        sys.exit(1)

    try:
        upload_skill(
            zip_path=zip_path,
            md_path=md_path,
            name=args.name,
            hub_url=args.hub_url,
            token=args.token,
            description=args.description,
            tags=args.tags,
            version=args.version,
        )
    except Exception as e:
        print(f"\nError: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
